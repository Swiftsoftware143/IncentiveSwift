//! IncentiveSwift Mechanics Engine
//!
//! Scoring, calculator, raffle draw, and loyalty check-in logic.

pub mod scoring;
pub mod calculator;
pub mod raffle_draw;
