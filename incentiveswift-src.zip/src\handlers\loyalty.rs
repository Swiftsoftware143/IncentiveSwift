//! Loyalty handlers — checkin, approve reward, deny reward.

use crate::error::AppError;
use crate::state::AppState;
use crate::security::auth::AuthenticatedUser;
use crate::db::{contacts, loyalty};
use axum::{
    extract::{Path, State},
    Json,
};
use serde::Deserialize;
use serde_json::{json, Value};
use uuid::Uuid;

/// Body for loyalty checkin.
#[derive(Deserialize)]
pub struct CheckinBody {
    pub program_slug: String,
    pub contact: super::entries::ContactBody,
    pub method: Option<String>,
}

/// POST /api/v1/loyalty/checkin — public-but-scoped.
/// Full flow: upsert contact -> find/create member -> check daily cap -> create entry
/// -> award points -> check thresholds -> auto-approve or pending -> push delivery.
pub async fn checkin(
    State(state): State<AppState>,
    Json(body): Json<CheckinBody>,
) -> Result<Json<Value>, AppError> {
    // 1. Upsert contact
    let contact_input = contacts::ContactInput {
        first_name: body.contact.first_name.clone(),
        last_name: body.contact.last_name.clone(),
        email: body.contact.email.clone(),
        phone: body.contact.phone.clone(),
        business_name: body.contact.business_name.clone(),
    };
    let contact_id = contacts::upsert_contact(&state.db, &contact_input).await?;

    // 2. Get loyalty program by slug — lookup from campaign slug
    let campaign = crate::db::campaigns::get_campaign_by_slug(&state.db, &body.program_slug).await?;
    let program = loyalty::get_program(&state.db, &campaign.id).await?;

    // 3. Find or create member
    let member_id = loyalty::find_or_create_member(&state.db, &program.id, &contact_id).await?;

    // 4. Check daily cap
    let today_count = loyalty::count_daily_checkins(&state.db, &member_id).await?;
    if today_count >= program.max_checkins_per_day as i64 {
        return Ok(Json(json!({
            "status": "daily_cap_reached",
            "message": format!("Come back tomorrow! Max {} check-in(s) per day.", program.max_checkins_per_day),
        })));
    }

    // 5. Award points: create an entry and checkin record
    let checkin_points = program.points_per_checkin;
    let entry_id = uuid::Uuid::new_v4();

    // Create a minimal entry for the checkin
    sqlx::query(
        r#"INSERT INTO entries (id, contact_id, campaign_id, answers, outcome, tags_applied)
           VALUES ($1, $2, $3, '{}'::jsonb, 'checkin', ARRAY['loyalty_checkin']::text[])"#
    )
    .bind(entry_id)
    .bind(contact_id)
    .bind(campaign.id)
    .execute(&state.db)
    .await?;

    loyalty::record_checkin(&state.db, &member_id, checkin_points, body.method.as_deref().unwrap_or("manual"), &entry_id).await?;

    // 6. Check reward tier thresholds
    let member = loyalty::get_member(&state.db, &member_id).await?;
    let new_balance = member.points_balance;
    let threshold_tier = loyalty::check_threshold_crossed(&state.db, &program.id, &member_id, new_balance).await?;

    let mut reward_earned = false;
    let mut reward_tag = String::new();
    let mut reward_status = String::new();

    if let Some(tier) = threshold_tier {
        reward_tag = tier.reward_tag.clone();
        if !tier.requires_approval {
            // Auto-approve
            let _reward_id = loyalty::create_reward(&state.db, &member_id, &tier.id, "approved").await?;
            loyalty::apply_reward_tag(&state.db, &contact_id, &tier.reward_tag).await?;
            reward_status = "approved".to_string();
        } else {
            // Requires manual approval
            let _reward_id = loyalty::create_reward(&state.db, &member_id, &tier.id, "pending").await?;
            reward_status = "pending".to_string();
        }
        reward_earned = true;
    }

    Ok(Json(json!({
        "status": "ok",
        "member_id": member_id,
        "points_balance": new_balance,
        "points_awarded": checkin_points,
        "lifetime_points": member.lifetime_points,
        "reward_earned": reward_earned,
        "reward_tag": reward_tag,
        "reward_status": reward_status,
    })))
}

/// Body for approving a reward.
#[derive(Deserialize)]
pub struct ApproveBody {
    pub approved_by: Option<String>,
}

/// POST /api/v1/loyalty/rewards/:id/approve — authenticated.
pub async fn approve_reward(
    State(state): State<AppState>,
    Path(id): Path<String>,
    _user: AuthenticatedUser,
    Json(body): Json<ApproveBody>,
) -> Result<Json<Value>, AppError> {
    let reward_id = Uuid::parse_str(&id)
        .map_err(|_| AppError::BadRequest("Invalid reward ID".to_string()))?;

    // Get reward
    let reward = loyalty::get_reward(&state.db, &reward_id).await?;

    if reward.status != "pending" {
        return Err(AppError::BadRequest(format!(
            "Reward is already {}", reward.status
        )));
    }

    let approved_by = body.approved_by
        .and_then(|s| Uuid::parse_str(&s).ok());

    // Update to approved
    loyalty::update_reward_status(
        &state.db,
        &reward_id,
        "approved",
        approved_by.as_ref(),
    ).await?;

    // Get tier info for tag
    let tier = loyalty::get_reward_tier(&state.db, &reward.tier_id).await?;

    // Get member to find contact_id
    let member = loyalty::get_member(&state.db, &reward.member_id).await?;

    // Apply reward tag to contact
    loyalty::apply_reward_tag(&state.db, &member.contact_id, &tier.reward_tag).await?;

    Ok(Json(json!({
        "status": "approved",
        "reward_id": id,
        "reward_tag": tier.reward_tag,
        "message": "Reward approved and tag applied"
    })))
}

/// POST /api/v1/loyalty/rewards/:id/deny — authenticated.
pub async fn deny_reward(
    State(state): State<AppState>,
    Path(id): Path<String>,
    _user: AuthenticatedUser,
) -> Result<Json<Value>, AppError> {
    let reward_id = Uuid::parse_str(&id)
        .map_err(|_| AppError::BadRequest("Invalid reward ID".to_string()))?;

    // Get reward
    let reward = loyalty::get_reward(&state.db, &reward_id).await?;

    if reward.status != "pending" {
        return Err(AppError::BadRequest(format!(
            "Reward is already {}", reward.status
        )));
    }

    // Update to denied
    loyalty::update_reward_status(
        &state.db,
        &reward_id,
        "denied",
        None,
    ).await?;

    Ok(Json(json!({
        "status": "denied",
        "reward_id": id,
        "message": "Reward denied"
    })))
}
